/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Model;

import java.sql.Date;

/**
 *
 * @author Martin
 */
public class Member {
    private String idMember;
    private String namaMember;
    private String alamatMember;
    private String tanggalLahirMember;
    private String emailMember;
    private String noTelpMember;

    public Member() {
    }

    public String getIdMember() {
        return idMember;
    }

    public void setIdMember(String idMember) {
        this.idMember = idMember;
    }

    public String getNamaMember() {
        return namaMember;
    }

    public void setNamaMember(String namaMember) {
        this.namaMember = namaMember;
    }

    public String getAlamatMember() {
        return alamatMember;
    }

    public void setAlamatMember(String alamatMember) {
        this.alamatMember = alamatMember;
    }

    public String getTanggalLahirMember() {
        return tanggalLahirMember;
    }

    public void setTanggalLahirMember(String tanggalLahirMember) {
        this.tanggalLahirMember = tanggalLahirMember;
    }

    public String getEmailMember() {
        return emailMember;
    }

    public void setEmailMember(String emailMember) {
        this.emailMember = emailMember;
    }

    public String getNoTelpMember() {
        return noTelpMember;
    }

    public void setNoTelpMember(String noTelpMember) {
        this.noTelpMember = noTelpMember;
    }       
}

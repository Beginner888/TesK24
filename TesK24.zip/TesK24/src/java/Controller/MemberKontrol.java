/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Koneksi.Koneksi;
import Model.Member;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Martin
 */
public class MemberKontrol {

    public static String buatIdMember() {
        Random r = new Random(System.currentTimeMillis());
        return "M" + String.valueOf((1 + r.nextInt(2)) * 1000 + r.nextInt(1000));
    }

    //method tambah member
    public void tambahMember(Member member) {

        try {
            Connection conn = Koneksi.getKoneksi();
            conn.setAutoCommit(false);
            PreparedStatement stat;
            String sql = "insert into member values (?,?,?,?,?,?)";
            stat = conn.prepareStatement(sql);
            stat.setString(1, member.getIdMember());
            stat.setString(2, member.getNamaMember());
            stat.setString(3, member.getAlamatMember());
            stat.setString(4, member.getTanggalLahirMember());
            stat.setString(5, member.getEmailMember());
            stat.setString(6, member.getNoTelpMember());
            stat.executeUpdate();
            conn.commit();
            conn.close();
        } catch (SQLException ex) {
            Logger.getLogger(UserKontrol.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    //method update member
    public void updateDataMember(Member member) {

        try {
            Connection conn = Koneksi.getKoneksi();
            conn.setAutoCommit(false);
            String sql = "update member set namamember = ?,alamatmember = ?, tanggallahirmember = ?, emailmember = ?, notelpmember = ? where idmember = ?";
            PreparedStatement stat = conn.prepareStatement(sql);
            stat.setString(1, member.getNamaMember());
            stat.setString(2, member.getAlamatMember());
            stat.setString(3, member.getTanggalLahirMember());
            stat.setString(4, member.getEmailMember());
            stat.setString(5, member.getNoTelpMember());
            stat.setString(6, member.getIdMember());
            stat.executeUpdate();
            conn.commit();
            conn.close();
        } catch (SQLException ex) {
            Logger.getLogger(UserKontrol.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    //method hapus member
    public void hapusMember(String idmember) {
        try {
            Connection conn = Koneksi.getKoneksi();
            conn.setAutoCommit(false);
            String sql = "delete from member where idmember = ?";
            PreparedStatement statement = conn.prepareStatement(sql);
            statement.setString(1, idmember);
            statement.executeUpdate();
            statement.close();
            conn.commit();
            conn.close();
        } catch (SQLException ex) {
            Logger.getLogger(UserKontrol.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    //lihat satu member
    public Member lihatSatuMember(String idmember) {
        try {
            Connection conn = Koneksi.getKoneksi();
            String sql = "select * from member where idmember = '" + idmember + "'";
            PreparedStatement statement = conn.prepareStatement(sql);
            ResultSet result = statement.executeQuery();
            Member member = new Member();
            while (result.next()) {
                member.setIdMember(result.getString(1));
                member.setNamaMember(result.getString(2));
                member.setAlamatMember(result.getString(3));
                member.setTanggalLahirMember(result.getString(4));
                member.setEmailMember(result.getString(5));
                member.setNoTelpMember(result.getString(6));
            }
            statement.close();
            conn.close();
            return member;
        } catch (SQLException ex) {
            Logger.getLogger(MemberKontrol.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    //method tampil member
    public List<Member> lihatSemuaMember() throws SQLException {
        Connection conn = Koneksi.getKoneksi();
        String sql = "select * from member";
        PreparedStatement statement = conn.prepareStatement(sql);
        ResultSet result = statement.executeQuery();
        List<Member> memberList = new ArrayList<>();
        while (result.next()) {
            Member member = new Member();
            member.setIdMember(result.getString(1));
            member.setNamaMember(result.getString(2));
            member.setAlamatMember(result.getString(3));
            member.setTanggalLahirMember(result.getString(4));
            member.setEmailMember(result.getString(5));
            member.setNoTelpMember(result.getString(6));
            memberList.add(member);
        }
        statement.close();
        conn.close();
        return memberList;
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.User;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Martin
 */
@WebServlet(name = "tambahuserServlet", urlPatterns = {"/tambahuserServlet"})
public class tambahuserServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet tambahuserServlet</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet tambahuserServlet at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String cek = null;
        UserKontrol uk = new UserKontrol();
        User user = new User();

        String username = request.getParameter("username");
        String password = request.getParameter("password");
        

        if (username.equals("") || password.equals("")) {
            cek = "gagal";
        } else {
            try {
                List<User> userList = uk.lihatSemuaUser();
                String status = "tersedia";
                for (int i = 0; i < userList.size(); i++) {
                    if (userList.get(i).getUsername().equals(username)) {
                        status = "terpakai";
                    }
                }
                if (status.equals("terpakai")) {
                    cek = "gagal";
                } else if (status.equals("tersedia")) {
                    user.setUsername(username);
                    user.setPassword(password);

                    uk.tambahUser(user);
                    cek = "berhasil";
                }
            } catch (SQLException ex) {
                Logger.getLogger(tambahuserServlet.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        

        request.setAttribute("cek", cek);
        if (cek.equals("berhasil")) {
            RequestDispatcher view = request.getRequestDispatcher("halaman-tambah-user.jsp");
            view.forward(request, response);
        } else {
            RequestDispatcher view = request.getRequestDispatcher("halaman-tambah-user.jsp");
            view.forward(request, response);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Koneksi.Koneksi;
import Model.User;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Martin
 */
public class UserKontrol {

    //method tambah user
    public void tambahUser(User user) {

        try {
            Connection conn = Koneksi.getKoneksi();
            conn.setAutoCommit(false);
            PreparedStatement stat;
            String sql = "insert into user values (?,?)";
            stat = conn.prepareStatement(sql);
            stat.setString(1, user.getUsername());
            stat.setString(2, user.getPassword());
            stat.executeUpdate();
            conn.commit();
            conn.close();
        } catch (SQLException ex) {
            Logger.getLogger(UserKontrol.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    //method update password
    public void updatePassword(User user) {

        try {
            Connection conn = Koneksi.getKoneksi();
            conn.setAutoCommit(false);
            String sql = "update user set password = ? where username = ?";
            PreparedStatement stat = conn.prepareStatement(sql);
            stat.setString(1, user.getPassword());
            stat.setString(2, user.getUsername());
            stat.executeUpdate();
            conn.commit();
            conn.close();
        } catch (SQLException ex) {
            Logger.getLogger(UserKontrol.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    //method hapus user
    public void hapusUser(String username) {
        try {
            Connection conn = Koneksi.getKoneksi();
            conn.setAutoCommit(false);
            String sql = "delete from user where username = ?";
            PreparedStatement statement = conn.prepareStatement(sql);
            statement.setString(1, username);
            statement.executeUpdate();
            statement.close();
            conn.commit();
            conn.close();
        } catch (SQLException ex) {
            Logger.getLogger(UserKontrol.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    //method tampil user
    public List<User> lihatSemuaUser() throws SQLException {
        Connection conn = Koneksi.getKoneksi();
        String sql = "select * from user";
        PreparedStatement statement = conn.prepareStatement(sql);
        ResultSet result = statement.executeQuery();
        List<User> userList = new ArrayList<>();
        while (result.next()) {
            User user = new User();
            user.setUsername(result.getString(1));
            userList.add(user);
        }
        statement.close();
        conn.close();
        return userList;
    }

    public String cekPassword(String username) {
        try {
            Connection conn = Koneksi.getKoneksi();
            String sql = "select password from user where username = '" + username + "'";
            PreparedStatement statement = conn.prepareStatement(sql);
            ResultSet result = statement.executeQuery();
            String temp = "";
            while (result.next()) {
                temp = result.getString(1);
            }
            statement.close();
            conn.close();
            return temp;
        } catch (SQLException ex) {
            Logger.getLogger(UserKontrol.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Koneksi;

import com.mysql.jdbc.jdbc2.optional.MysqlDataSource;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Gabriel
 */
public class Koneksi {

    public static Connection getKoneksi() {
        String jdbcUrl = "jdbc:mysql://localhost:3306/k24";
        String userid = "root";
        String password = "";
        Connection conn = null;
        try {
            MysqlDataSource ds;
            ds = new MysqlDataSource();
            ds.setURL(jdbcUrl);
            conn = ds.getConnection(userid, password);
        } catch (SQLException ex) {
            Logger.getLogger(Koneksi.class.getName()).log(Level.SEVERE, null, ex);
        }
        return conn;
    }
}
